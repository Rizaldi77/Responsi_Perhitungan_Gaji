
package gajiresponsi;

import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class GajiPegawaiView extends JFrame {
    JLabel footer, bg, lid, lnama, lposisi, lalamat, lnohp, lgajipkk, ljam, ltunjangan, lpajak, ltotal;
    JTextField txid, txnama, txposisi, txalamat, txnohp, txgajipkk, txjam, txtunjangan, txpajak, txtotal;
    JButton btnhome, btnadmin, btnpetunjuk, btngaji, btndata, btnsimpan, btnhitung;
    ImageIcon ghome, gadmin, gpetunjuk, ggaji, gdata, gsimpan, ghitung;
    
    public GajiPegawaiView(){
        footer = new JLabel("APLIKASI PENGHITUNGAN GAJI PT VETERAN JAYA");
        footer.setFont(new Font("Arial Black", Font.PLAIN, 26));
        footer.setBackground(Color.WHITE);
        ghome = new ImageIcon(getClass().getResource("/image/home.png"));
        btnhome    = new JButton("HOME",ghome);
        gdata = new ImageIcon(getClass().getResource("/image/doc.png"));
        btndata    = new JButton("DATA",gdata);
        ggaji = new ImageIcon(getClass().getResource("/image/pegawai.png"));
        btngaji    = new JButton("GAJI",ggaji);
        gpetunjuk = new ImageIcon(getClass().getResource("/image/help.png"));
        btnpetunjuk    = new JButton("PETUNJUK",gpetunjuk);
        gadmin = new ImageIcon(getClass().getResource("/image/admin.png"));
        btnadmin    = new JButton("ADMIN",gadmin);
        gsimpan = new ImageIcon(getClass().getResource("/image/save.png"));
        btnsimpan    = new JButton("SIMPAN",gsimpan);
        ghitung = new ImageIcon(getClass().getResource("/image/hitung.png"));
        btnhitung    = new JButton("HITUNG",ghitung);
        bg = new JLabel(new ImageIcon(getClass().getResource("/image/bg2_1.png")));
        
        setLayout(null);
        add(btnhome);
        add(btndata);
        add(btngaji);
        add(btnpetunjuk);
        add(btnadmin);
        add(footer);
        add(btnsimpan);
        add(btnhitung);
        add(bg);
        
        btnhome.setBounds(25, 25, 240, 135);
        btngaji.setBounds(25, 175, 240, 135);
        btndata.setBounds(25, 325, 240, 135);
        btnadmin.setBounds(1000, 25, 240, 135);
        btnpetunjuk.setBounds(25, 475, 240, 135);
        footer.setBounds(425, 650, 700, 150);
        btnsimpan.setBounds(1000, 575, 240, 135);
        btnhitung.setBounds(1000, 425, 240, 135);
        bg.setBounds(0, 0, 1300, 800);
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setLayout(null);
        setSize(1300, 800);
    }
}
