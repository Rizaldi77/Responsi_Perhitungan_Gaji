
package gajiresponsi;

public class HomePegawaiModel {
    
}
