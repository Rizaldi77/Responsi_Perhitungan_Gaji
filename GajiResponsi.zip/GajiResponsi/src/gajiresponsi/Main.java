
package gajiresponsi;

public class Main {

    public static void main(String[] args) {
        HomePegawaiMVC awal = new HomePegawaiMVC();
    }
    
}
