
package gajiresponsi;

public class HomePegawaiMVC {
    HomePegawaiView homepegawaiview = new HomePegawaiView();
    HomePegawaiController controller = new HomePegawaiController(homepegawaiview);
}
