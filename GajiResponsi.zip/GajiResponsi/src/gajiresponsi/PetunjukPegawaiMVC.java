
package gajiresponsi;

public class PetunjukPegawaiMVC {
    PetunjukPegawaiView petunjukpegawaiview = new PetunjukPegawaiView();
    PetunjukPegawaiController petunjukpegawaicontroller = new PetunjukPegawaiController(petunjukpegawaiview);
}
