
package gajiresponsi;

public class DataPegawaiModel {
    
}
